window.onload = function() {
  // set student info into main window
  Student.updateHTML();
};
